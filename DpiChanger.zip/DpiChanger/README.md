# DPI Changer — Panduan Build APK

## Prasyarat
- **Android Studio** Ladybug (2024.2) atau lebih baru
- **JDK 17** (sudah bundled di Android Studio terbaru)
- **Shizuku** terinstall di perangkat Android Anda
- Perangkat Android minimal **Android 9 (API 28)**

---

## Langkah Build APK

### 1. Buka Proyek
```
File → Open → pilih folder DpiChanger ini
```
Tunggu Gradle sync selesai (~2-5 menit, tergantung koneksi internet).

### 2. Build APK Debug (untuk testing)
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK tersimpan di: `app/build/outputs/apk/debug/app-debug.apk`

### 3. Install ke Perangkat
```
adb install app/build/outputs/apk/debug/app-debug.apk
```
Atau drag & drop file APK ke emulator/perangkat yang terhubung.

---

## Langkah Penggunaan Aplikasi

1. Install **Shizuku** dari [Play Store](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api)
2. Aktifkan Shizuku (via ADB wireless atau mode developer MIUI/OneUI)
3. Buka **DPI Changer**
4. Tekan **"Minta Izin Shizuku"** → setujui dialog
5. Tekan **"Tampilkan Notifikasi Kontrol DPI"**
6. Di notification bar, ketik nilai DPI (contoh: `420`) lalu send
7. DPI berubah instan tanpa reboot!

---

## Struktur Proyek

```
DpiChanger/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/example/dpichanger/
│   │   ├── MainActivity.kt         ← UI & lifecycle Shizuku
│   │   ├── ShizukuHelper.kt        ← Logika inti (singleton)
│   │   ├── DpiActionReceiver.kt    ← Proses input notifikasi
│   │   └── NotificationHelper.kt  ← Manajemen notifikasi
│   └── res/
│       ├── layout/activity_main.xml
│       ├── drawable/               ← Icon & background
│       └── values/                 ← Strings, colors, themes
├── gradle/libs.versions.toml       ← Version catalog
└── build.gradle.kts
```

---

## Rentang DPI yang Direkomendasikan

| Perangkat | DPI Biasa | DPI Compact | DPI Besar |
|-----------|-----------|-------------|-----------|
| Phone 5-6" | 360-420 | 280-320 | 480-560 |
| Phone 6-7" | 320-400 | 260-300 | 440-520 |
| Tablet 10" | 240-320 | 180-220 | 360-440 |

Ketik `0` untuk reset ke DPI default pabrik.

---

## Troubleshoot

**"Shizuku tidak aktif"** → Buka app Shizuku → Start → pilih metode aktivasi

**"Gagal mengubah DPI"** → Pastikan versi Shizuku ≥ 13.x dan izin sudah diberikan

**Notifikasi tidak muncul** → Settings → Apps → DPI Changer → Notifications → Allow
