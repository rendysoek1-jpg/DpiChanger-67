# Shizuku — jangan di-obfuscate
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }

# Pertahankan BroadcastReceiver agar tidak di-strip oleh ProGuard
-keep public class com.example.dpichanger.DpiActionReceiver { *; }

# AndroidX & Material
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
