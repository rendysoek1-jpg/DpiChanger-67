plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.dpichanger"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.dpichanger"
        minSdk = 28 // Minimum SDK 28 (Android 9) untuk Shizuku
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // Shizuku API — inti library untuk eksekusi shell tanpa root
    implementation("dev.rikka.shizuku:api:13.1.5")

    // Shizuku Provider — wajib untuk aplikasi yang BUKAN Shizuku itu sendiri
    implementation("dev.rikka.shizuku:provider:13.1.5")

    // AndroidX & Material
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
