package com.example.dpichanger

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.dpichanger.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/**
 * MainActivity
 *
 * Titik masuk utama aplikasi. Bertanggung jawab atas:
 *
 * 1. Inisialisasi NotificationChannel (harus dilakukan sekali saat aplikasi pertama dibuka)
 * 2. Mengelola lifecycle listener Shizuku (binderReceived & binderDead)
 * 3. Meminta izin notifikasi (Android 13+)
 * 4. Meminta izin Shizuku dari user
 * 5. Menampilkan status koneksi Shizuku di UI
 * 6. Menampilkan notifikasi kontrol DPI ketika semua izin terpenuhi
 *
 * ╔══════════════════════════════════════════════════════╗
 * ║  LIFECYCLE SHIZUKU LISTENER                          ║
 * ║  Shizuku dapat mati & restart kapan saja (mis.       ║
 * ║  setelah reboot). Listener wajib didaftarkan di      ║
 * ║  onCreate() dan di-remove di onDestroy() untuk       ║
 * ║  mencegah memory leak.                               ║
 * ╚══════════════════════════════════════════════════════╝
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "MainActivity"
    }

    private lateinit var binding: ActivityMainBinding

    // ════════════════════════════════════════════════════════════════
    // SHIZUKU BINDER LISTENERS
    // ════════════════════════════════════════════════════════════════

    /**
     * Dipanggil ketika Shizuku service berhasil terhubung (binder received).
     * Ini terjadi saat:
     * - Aplikasi pertama dibuka setelah Shizuku aktif
     * - Shizuku restart/update dan kembali terhubung
     */
    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.i(TAG, "Shizuku binder diterima — service aktif")
        runOnUiThread {
            updateShizukuStatus()
        }
    }

    /**
     * Dipanggil ketika koneksi ke Shizuku service terputus.
     * Ini terjadi saat:
     * - Shizuku di-stop secara manual
     * - Perangkat restart (Shizuku belum aktif lagi)
     * - Shizuku crash
     */
    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder mati — service tidak aktif")
        runOnUiThread {
            updateShizukuStatus()
            showToast("Shizuku tidak aktif. Pastikan Shizuku sudah dijalankan.")
        }
    }

    /**
     * Listener untuk hasil permintaan izin Shizuku.
     * Dipanggil setelah user menerima atau menolak dialog izin Shizuku.
     *
     * PENTING: Listener ini harus di-remove setelah digunakan
     * (ditangani di ShizukuHelper.removePermissionListener).
     */
    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            Log.i(TAG, "Hasil izin Shizuku — code: $requestCode, granted: $granted")

            runOnUiThread {
                updateShizukuStatus()
                if (granted) {
                    showToast("Izin Shizuku diberikan! Notifikasi kontrol siap digunakan.")
                    showMainNotificationIfReady()
                } else {
                    showToast("Izin Shizuku ditolak. Aplikasi tidak dapat mengubah DPI.")
                }
            }

            // Bersihkan listener setelah selesai
            ShizukuHelper.removePermissionListener(this.permissionResultListener)
        }

    // ════════════════════════════════════════════════════════════════
    // PERMISSION LAUNCHER (Android 13+)
    // ════════════════════════════════════════════════════════════════

    /**
     * Launcher untuk meminta izin POST_NOTIFICATIONS (Android 13+).
     * Harus didaftarkan sebelum Activity resume.
     */
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                Log.i(TAG, "Izin notifikasi diberikan")
                showMainNotificationIfReady()
            } else {
                Log.w(TAG, "Izin notifikasi ditolak")
                showToast("Izin notifikasi diperlukan untuk menampilkan kontrol DPI.")
            }
        }

    // ════════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ── 1. Inisialisasi NotificationChannel (sekali saja) ──
        NotificationHelper.createNotificationChannels(this)

        // ── 2. Daftarkan Shizuku lifecycle listeners ──
        // Listeners ini memantau kondisi Shizuku service secara real-time
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        // "Sticky" = jika Shizuku sudah aktif sebelum listener didaftarkan,
        //            listener langsung dipanggil dengan kondisi terkini.

        Shizuku.addBinderDeadListener(binderDeadListener)

        // ── 3. Setup tombol-tombol di UI ──
        setupUI()

        // ── 4. Cek status awal ──
        updateShizukuStatus()
    }

    override fun onResume() {
        super.onResume()
        // Perbarui status setiap kali user kembali ke aplikasi
        // (misalnya setelah mengaktifkan Shizuku di aplikasi lain)
        updateShizukuStatus()
    }

    override fun onDestroy() {
        super.onDestroy()

        // WAJIB: Remove semua listener untuk mencegah memory leak
        // Jika tidak di-remove, Shizuku akan terus menyimpan reference ke Activity
        // yang sudah destroyed → memory leak
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        ShizukuHelper.removePermissionListener(permissionResultListener)

        Log.d(TAG, "onDestroy: semua listener Shizuku berhasil di-remove")
    }

    // ════════════════════════════════════════════════════════════════
    // SETUP UI
    // ════════════════════════════════════════════════════════════════

    private fun setupUI() {
        // Tombol: Minta Izin Shizuku
        binding.btnRequestShizukuPermission.setOnClickListener {
            requestShizukuPermission()
        }

        // Tombol: Tampilkan Notifikasi Kontrol DPI
        binding.btnShowNotification.setOnClickListener {
            showMainNotificationIfReady()
        }

        // Tombol: Refresh status
        binding.btnRefreshStatus.setOnClickListener {
            refreshStatusWithDpi()
        }

        // Tombol: Set DPI langsung dari aplikasi (opsional, untuk kemudahan testing)
        binding.btnSetDpiFromApp.setOnClickListener {
            val dpiText = binding.etDpiInput.text?.toString()?.trim()
            val dpi = dpiText?.toIntOrNull()

            if (dpi == null) {
                showToast("Masukkan angka DPI yang valid")
                return@setOnClickListener
            }

            setDpiFromApp(dpi)
        }
    }

    // ════════════════════════════════════════════════════════════════
    // STATUS UI UPDATE
    // ════════════════════════════════════════════════════════════════

    /**
     * Memperbarui semua indikator status di UI berdasarkan kondisi Shizuku saat ini.
     */
    private fun updateShizukuStatus() {
        val isAvailable = ShizukuHelper.isShizukuAvailable()
        val hasPermission = ShizukuHelper.hasShizukuPermission()

        // Status Shizuku Service
        binding.tvShizukuAvailability.apply {
            text = if (isAvailable) "✅ Shizuku Service: Aktif" else "❌ Shizuku Service: Tidak Aktif"
            setTextColor(
                if (isAvailable) getColor(android.R.color.holo_green_dark)
                else getColor(android.R.color.holo_red_dark)
            )
        }

        // Status Izin
        binding.tvShizukuPermission.apply {
            text = when {
                !isAvailable -> "⏸ Izin: N/A (Shizuku tidak aktif)"
                hasPermission -> "✅ Izin Shell: Diberikan"
                else -> "❌ Izin Shell: Belum diberikan"
            }
            setTextColor(
                if (hasPermission) getColor(android.R.color.holo_green_dark)
                else getColor(android.R.color.holo_orange_dark)
            )
        }

        // Status Siap Digunakan
        val isReady = isAvailable && hasPermission
        binding.tvOverallStatus.text = if (isReady) {
            "🟢 Aplikasi siap — Gunakan notifikasi untuk mengubah DPI"
        } else {
            "🔴 Belum siap — Ikuti langkah di bawah ini"
        }

        // Enable/disable tombol berdasarkan kondisi
        binding.btnRequestShizukuPermission.isEnabled = isAvailable && !hasPermission
        binding.btnShowNotification.isEnabled = isReady
        binding.btnSetDpiFromApp.isEnabled = isReady
    }

    /**
     * Refresh status + baca DPI saat ini secara asinkron (agar tidak blocking UI thread).
     */
    private fun refreshStatusWithDpi() {
        updateShizukuStatus()
        binding.tvCurrentDpi.text = "DPI Saat Ini: Membaca..."

        lifecycleScope.launch {
            val currentDpi = withContext(Dispatchers.IO) {
                ShizukuHelper.getCurrentDpi()
            }
            binding.tvCurrentDpi.text = currentDpi?.let {
                "DPI Saat Ini: $it"
            } ?: "DPI Saat Ini: Tidak dapat dibaca"
        }
    }

    // ════════════════════════════════════════════════════════════════
    // SHIZUKU PERMISSION
    // ════════════════════════════════════════════════════════════════

    /**
     * Memulai alur permintaan izin Shizuku.
     * Menampilkan dialog izin Shizuku ke user.
     */
    private fun requestShizukuPermission() {
        when {
            !ShizukuHelper.isShizukuAvailable() -> {
                showToast("Shizuku belum aktif. Buka aplikasi Shizuku dan aktifkan service-nya.")
            }

            ShizukuHelper.hasShizukuPermission() -> {
                showToast("Izin Shizuku sudah diberikan!")
                showMainNotificationIfReady()
            }

            else -> {
                Log.d(TAG, "Meminta izin Shizuku dari user")
                ShizukuHelper.requestPermission(permissionResultListener)
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // NOTIFIKASI
    // ════════════════════════════════════════════════════════════════

    /**
     * Menampilkan notifikasi utama DPI controller.
     * Memeriksa semua prasyarat sebelum menampilkan.
     */
    private fun showMainNotificationIfReady() {
        // Cek izin notifikasi (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifPermission = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            )
            if (notifPermission != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }

        // Cek Shizuku
        if (!ShizukuHelper.isShizukuAvailable()) {
            showToast("Shizuku belum aktif.")
            return
        }

        if (!ShizukuHelper.hasShizukuPermission()) {
            showToast("Izin Shizuku diperlukan. Tekan tombol 'Minta Izin Shizuku'.")
            return
        }

        // Semua OK — tampilkan notifikasi dengan membaca DPI terlebih dahulu
        lifecycleScope.launch {
            val currentDpi = withContext(Dispatchers.IO) {
                ShizukuHelper.getCurrentDpi()
            }
            NotificationHelper.showMainNotification(this@MainActivity, currentDpi)
            showToast("Notifikasi kontrol DPI ditampilkan!")
        }
    }

    // ════════════════════════════════════════════════════════════════
    // AKSI LANGSUNG DARI APP
    // ════════════════════════════════════════════════════════════════

    /**
     * Set DPI langsung dari input di MainActivity (untuk kemudahan testing).
     * Logika validasi tetap dihandle oleh ShizukuHelper.
     */
    private fun setDpiFromApp(dpi: Int) {
        lifecycleScope.launch {
            binding.btnSetDpiFromApp.isEnabled = false
            binding.tvOverallStatus.text = "⏳ Mengubah DPI ke $dpi..."

            val result = withContext(Dispatchers.IO) {
                ShizukuHelper.setSystemDpi(dpi)
            }

            when (result) {
                is ShizukuHelper.DpiResult.Success -> {
                    showToast(result.message)
                    // Beri sedikit delay sebelum refresh agar sistem sempat menerapkan DPI baru
                    delay(500)
                    refreshStatusWithDpi()
                }

                is ShizukuHelper.DpiResult.Error -> {
                    showToast(result.message)
                    updateShizukuStatus()
                }
            }

            binding.btnSetDpiFromApp.isEnabled = ShizukuHelper.hasShizukuPermission()
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HELPER
    // ════════════════════════════════════════════════════════════════

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
