package com.example.dpichanger

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.RemoteInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * DpiActionReceiver
 *
 * BroadcastReceiver yang memproses semua aksi dari notifikasi:
 *
 * ┌─────────────────────────────────────────────────────────┐
 * │  ACTION_SET_DPI   → Baca RemoteInput → Validasi → Set   │
 * │  ACTION_RESET_DPI → Reset DPI ke default pabrik         │
 * │  ACTION_DISMISS   → Tutup notifikasi utama              │
 * └─────────────────────────────────────────────────────────┘
 *
 * CATATAN ARSITEKTUR:
 * - BroadcastReceiver memiliki window eksekusi sangat singkat (~10 detik).
 * - Untuk operasi yang mungkin memakan waktu (eksekusi shell), gunakan Coroutine
 *   dengan goAsync() agar tidak di-kill oleh sistem sebelum selesai.
 * - Jangan simpan reference ke Context di luar scope onReceive()
 *   → menyebabkan memory leak karena Context bisa saja sudah destroyed.
 */
class DpiActionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "DpiActionReceiver"

        // Coroutine scope dengan SupervisorJob:
        // SupervisorJob memastikan satu coroutine gagal tidak membatalkan yang lain.
        // Scope ini hidup selama aplikasi berjalan (object-level), aman untuk receiver.
        private val receiverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    }

    override fun onReceive(context: Context, intent: Intent) {
        Log.d(TAG, "onReceive dipanggil | action: ${intent.action}")

        // goAsync() → memberi tahu sistem bahwa kita butuh lebih banyak waktu.
        // Kembalikan PendingResult dan selesaikan di Coroutine.
        val pendingResult = goAsync()

        receiverScope.launch {
            try {
                when (intent.action) {
                    NotificationHelper.ACTION_SET_DPI -> handleSetDpi(context, intent)
                    NotificationHelper.ACTION_RESET_DPI -> handleResetDpi(context)
                    NotificationHelper.ACTION_DISMISS -> handleDismiss(context)
                    else -> Log.w(TAG, "Action tidak dikenal: ${intent.action}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error tidak tertangani di onReceive: ${e.message}", e)
                // Tampilkan notifikasi error generik ke user
                NotificationHelper.showFeedbackNotification(
                    context = context,
                    success = false,
                    message = "Terjadi error tidak terduga: ${e.message}"
                )
            } finally {
                // WAJIB: Beritahu sistem bahwa receiver sudah selesai bekerja
                // Jika tidak dipanggil → memory leak & sistem tidak dapat membersihkan receiver
                pendingResult.finish()
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HANDLER: SET DPI
    // ════════════════════════════════════════════════════════════════

    /**
     * Memproses input DPI dari RemoteInput notifikasi.
     *
     * Alur:
     * 1. Ambil teks dari RemoteInput Bundle
     * 2. Validasi: harus berupa angka
     * 3. Panggil ShizukuHelper.setSystemDpi()
     * 4. Tampilkan feedback notifikasi
     * 5. Update notifikasi utama dengan DPI terbaru
     */
    private fun handleSetDpi(context: Context, intent: Intent) {
        // ── 1. Ambil input dari RemoteInput ──
        // RemoteInput menyimpan hasil ketikan user di dalam Bundle Intent
        val remoteInputBundle = RemoteInput.getResultsFromIntent(intent)

        if (remoteInputBundle == null) {
            Log.w(TAG, "RemoteInput bundle null — user mungkin tidak mengetik apapun")
            NotificationHelper.showFeedbackNotification(
                context = context,
                success = false,
                message = "Input DPI tidak ditemukan. Silakan ketik angka DPI."
            )
            return
        }

        // Ambil teks berdasarkan key yang sudah kita definisikan
        val inputText = remoteInputBundle
            .getCharSequence(NotificationHelper.KEY_DPI_INPUT)
            ?.toString()
            ?.trim()

        Log.d(TAG, "Input DPI yang diterima: '$inputText'")

        // ── 2. Validasi: Input tidak boleh kosong ──
        if (inputText.isNullOrEmpty()) {
            NotificationHelper.showFeedbackNotification(
                context = context,
                success = false,
                message = "Input kosong. Silakan ketik nilai DPI (200–800) atau 0 untuk reset."
            )
            return
        }

        // ── 3. Validasi: Input harus berupa angka bulat ──
        val dpiValue = inputText.toIntOrNull()
        if (dpiValue == null) {
            NotificationHelper.showFeedbackNotification(
                context = context,
                success = false,
                message = "\"$inputText\" bukan angka yang valid. Masukkan angka seperti 420 atau 320."
            )
            return
        }

        // ── 4. Serahkan ke ShizukuHelper untuk validasi lanjutan & eksekusi ──
        val result = ShizukuHelper.setSystemDpi(dpiValue)

        // ── 5. Tampilkan hasil ke user ──
        when (result) {
            is ShizukuHelper.DpiResult.Success -> {
                Log.i(TAG, "DPI berhasil diubah: ${result.message}")
                NotificationHelper.showFeedbackNotification(
                    context = context,
                    success = true,
                    message = result.message
                )
                // Perbarui notifikasi utama dengan DPI baru
                val newCurrentDpi = if (dpiValue == 0) null else dpiValue
                NotificationHelper.updateMainNotificationDpi(context, newCurrentDpi)
            }

            is ShizukuHelper.DpiResult.Error -> {
                Log.e(TAG, "Gagal mengubah DPI: ${result.message}")
                NotificationHelper.showFeedbackNotification(
                    context = context,
                    success = false,
                    message = result.message
                )
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HANDLER: RESET DPI
    // ════════════════════════════════════════════════════════════════

    /**
     * Mereset DPI ke nilai default pabrik perangkat.
     * Ekuivalen dengan mengirim DPI = 0 ke setSystemDpi().
     */
    private fun handleResetDpi(context: Context) {
        Log.d(TAG, "Memproses reset DPI")

        val result = ShizukuHelper.setSystemDpi(0) // 0 = reset

        when (result) {
            is ShizukuHelper.DpiResult.Success -> {
                NotificationHelper.showFeedbackNotification(
                    context = context,
                    success = true,
                    message = "DPI berhasil direset ke nilai default perangkat."
                )
                NotificationHelper.updateMainNotificationDpi(context, null)
            }

            is ShizukuHelper.DpiResult.Error -> {
                NotificationHelper.showFeedbackNotification(
                    context = context,
                    success = false,
                    message = "Gagal mereset DPI: ${result.message}"
                )
            }
        }
    }

    // ════════════════════════════════════════════════════════════════
    // HANDLER: DISMISS
    // ════════════════════════════════════════════════════════════════

    /**
     * Menghapus notifikasi utama ketika user meminta dismiss.
     */
    private fun handleDismiss(context: Context) {
        Log.d(TAG, "Notifikasi utama di-dismiss oleh user")
        NotificationHelper.dismissMainNotification(context)
    }
}
