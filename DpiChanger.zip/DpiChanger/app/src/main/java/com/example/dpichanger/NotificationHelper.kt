package com.example.dpichanger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput

/**
 * NotificationHelper
 *
 * Mengelola semua operasi notifikasi:
 * - Membuat NotificationChannel
 * - Menampilkan notifikasi utama dengan RemoteInput (inline reply)
 * - Menampilkan notifikasi feedback (sukses/error)
 */
object NotificationHelper {

    // ── Channel IDs ──
    const val CHANNEL_MAIN = "dpi_changer_main"       // Untuk notifikasi kontrol DPI
    const val CHANNEL_FEEDBACK = "dpi_changer_feedback" // Untuk notifikasi hasil

    // ── Notification IDs ──
    const val NOTIF_ID_MAIN = 1001       // Notifikasi utama (persistent)
    const val NOTIF_ID_FEEDBACK = 1002   // Notifikasi feedback (sementara)

    // ── Intent Actions ──
    const val ACTION_SET_DPI = "com.example.dpichanger.ACTION_SET_DPI"
    const val ACTION_RESET_DPI = "com.example.dpichanger.ACTION_RESET_DPI"
    const val ACTION_DISMISS = "com.example.dpichanger.ACTION_DISMISS"

    // ── RemoteInput Key ──
    // Key ini digunakan untuk mengambil teks yang diketik user dari Bundle
    const val KEY_DPI_INPUT = "key_dpi_input"

    // ════════════════════════════════════════════════════════════════
    // SETUP CHANNEL
    // ════════════════════════════════════════════════════════════════

    /**
     * Membuat semua NotificationChannel yang diperlukan.
     * HARUS dipanggil saat aplikasi pertama kali dibuat (di Application atau MainActivity.onCreate).
     * Aman dipanggil berulang kali — Android akan mengabaikan jika channel sudah ada.
     */
    fun createNotificationChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)

        // Channel 1: Kontrol DPI (persistent, muncul terus)
        val mainChannel = NotificationChannel(
            CHANNEL_MAIN,
            "DPI Controller",
            NotificationManager.IMPORTANCE_LOW // LOW = tidak bersuara, tidak bergetar
        ).apply {
            description = "Notifikasi kontrol utama untuk mengubah DPI layar"
            setShowBadge(false) // Tidak perlu badge di icon aplikasi
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        // Channel 2: Feedback hasil operasi (muncul sebentar lalu hilang)
        val feedbackChannel = NotificationChannel(
            CHANNEL_FEEDBACK,
            "DPI Status",
            NotificationManager.IMPORTANCE_DEFAULT // DEFAULT = ada suara notifikasi
        ).apply {
            description = "Notifikasi status hasil perubahan DPI"
            setShowBadge(true)
        }

        manager.createNotificationChannel(mainChannel)
        manager.createNotificationChannel(feedbackChannel)
    }

    // ════════════════════════════════════════════════════════════════
    // NOTIFIKASI UTAMA (dengan RemoteInput)
    // ════════════════════════════════════════════════════════════════

    /**
     * Menampilkan notifikasi utama yang memiliki:
     * 1. RemoteInput → user bisa mengetik angka DPI langsung dari notifikasi
     * 2. Tombol "Set DPI" → submit nilai yang diketik
     * 3. Tombol "Reset" → kembalikan DPI ke default
     *
     * @param currentDpi DPI saat ini untuk ditampilkan di body notifikasi.
     *                   null jika tidak berhasil dibaca.
     */
    fun showMainNotification(context: Context, currentDpi: Int? = null) {
        val manager = context.getSystemService(NotificationManager::class.java)

        // ── 1. RemoteInput: Input teks langsung dari notifikasi ──
        // RemoteInput memungkinkan user mengetik tanpa membuka aplikasi
        val remoteInput = RemoteInput.Builder(KEY_DPI_INPUT)
            .setLabel("Ketik DPI (200-800, atau 0 untuk reset)")
            .build()

        // ── 2. PendingIntent untuk aksi SET DPI ──
        val setDpiIntent = Intent(context, DpiActionReceiver::class.java).apply {
            action = ACTION_SET_DPI
        }
        val setDpiPendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            setDpiIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            // FLAG_MUTABLE wajib karena RemoteInput memodifikasi Intent saat runtime
        )

        // ── 3. Aksi "Set DPI" — menggabungkan RemoteInput dengan PendingIntent ──
        val setDpiAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_edit,
            "Set DPI",
            setDpiPendingIntent
        )
            .addRemoteInput(remoteInput) // Attach inline reply ke aksi ini
            .setAllowGeneratedReplies(false) // Matikan saran auto-reply
            .build()

        // ── 4. PendingIntent untuk tombol RESET ──
        val resetIntent = Intent(context, DpiActionReceiver::class.java).apply {
            action = ACTION_RESET_DPI
        }
        val resetPendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            resetIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val resetAction = NotificationCompat.Action.Builder(
            android.R.drawable.ic_menu_revert,
            "Reset Default",
            resetPendingIntent
        ).build()

        // ── 5. PendingIntent untuk membuka MainActivity saat notifikasi di-tap ──
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            2,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // ── 6. Bangun notifikasi ──
        val dpiInfo = currentDpi?.let { "DPI saat ini: $it" } ?: "Ketuk untuk membuka aplikasi"

        val notification = NotificationCompat.Builder(context, CHANNEL_MAIN)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("DPI Changer")
            .setContentText(dpiInfo)
            .setSubText("Shizuku Aktif")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$dpiInfo\n\nKetik nilai DPI (200–800) atau tekan Reset untuk kembali ke default pabrik.")
            )
            .setContentIntent(contentPendingIntent)
            .addAction(setDpiAction)  // Aksi dengan RemoteInput
            .addAction(resetAction)   // Aksi reset
            .setOngoing(true)         // Tidak bisa diswipe oleh user
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        manager.notify(NOTIF_ID_MAIN, notification)
    }

    // ════════════════════════════════════════════════════════════════
    // NOTIFIKASI FEEDBACK
    // ════════════════════════════════════════════════════════════════

    /**
     * Menampilkan notifikasi feedback singkat setelah operasi DPI.
     * Notifikasi ini auto-cancel setelah user tap.
     *
     * @param success true untuk sukses (icon hijau), false untuk error (icon merah)
     * @param message Pesan yang ditampilkan ke user
     */
    fun showFeedbackNotification(context: Context, success: Boolean, message: String) {
        val manager = context.getSystemService(NotificationManager::class.java)

        val iconRes = if (success) {
            android.R.drawable.ic_dialog_info
        } else {
            android.R.drawable.ic_dialog_alert
        }

        val title = if (success) "✅ Berhasil" else "❌ Gagal"

        val notification = NotificationCompat.Builder(context, CHANNEL_FEEDBACK)
            .setSmallIcon(iconRes)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true) // Hilang otomatis setelah di-tap
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .build()

        manager.notify(NOTIF_ID_FEEDBACK, notification)
    }

    /**
     * Memperbarui teks notifikasi utama setelah DPI berhasil diubah.
     * Dipanggil dari BroadcastReceiver setelah operasi sukses.
     */
    fun updateMainNotificationDpi(context: Context, newDpi: Int?) {
        showMainNotification(context, newDpi)
    }

    /**
     * Menghapus notifikasi utama.
     */
    fun dismissMainNotification(context: Context) {
        context.getSystemService(NotificationManager::class.java)
            .cancel(NOTIF_ID_MAIN)
    }
}
