package com.example.dpichanger

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * ShizukuHelper
 *
 * Kelas pembantu (helper) terpusat untuk semua operasi yang berkaitan
 * dengan Shizuku: pengecekan izin, permintaan izin, dan eksekusi perintah shell.
 *
 * Desain: object (singleton) agar mudah diakses dari mana saja tanpa
 * perlu membuat instance baru yang bisa menyebabkan listener menumpuk.
 */
object ShizukuHelper {

    private const val TAG = "ShizukuHelper"

    // Request code unik untuk permintaan izin Shizuku
    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    // ════════════════════════════════════════════════════════════════
    // PENGECEKAN STATUS SHIZUKU
    // ════════════════════════════════════════════════════════════════

    /**
     * Apakah Shizuku service sedang berjalan (sudah di-bind)?
     * Shizuku mungkin terinstall tapi belum aktif.
     */
    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku binder tidak tersedia: ${e.message}")
            false
        }
    }

    /**
     * Apakah aplikasi sudah memiliki izin untuk menggunakan Shizuku?
     * Menggunakan checkSelfPermission() — ekuivalen dengan permission check Android.
     */
    fun hasShizukuPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            Log.w(TAG, "Gagal memeriksa izin Shizuku: ${e.message}")
            false
        }
    }

    // ════════════════════════════════════════════════════════════════
    // PERMINTAAN IZIN
    // ════════════════════════════════════════════════════════════════

    /**
     * Meminta izin Shizuku dari pengguna.
     * Dialog izin akan muncul (mirip permission dialog Android).
     *
     * @param listener Callback yang akan dipanggil saat user menerima/menolak izin.
     *                 Listener ini harus di-remove setelah selesai (lihat removeRequestPermissionResultListener).
     */
    fun requestPermission(listener: Shizuku.OnRequestPermissionResultListener) {
        if (!isShizukuAvailable()) {
            Log.e(TAG, "Tidak bisa meminta izin: Shizuku service tidak aktif")
            return
        }
        try {
            // Daftarkan listener sebelum request
            Shizuku.addRequestPermissionResultListener(listener)
            // Kirim permintaan izin
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        } catch (e: Exception) {
            Log.e(TAG, "Gagal meminta izin Shizuku: ${e.message}")
            Shizuku.removeRequestPermissionResultListener(listener)
        }
    }

    /**
     * Hapus listener izin setelah tidak diperlukan lagi.
     * WAJIB dipanggil untuk mencegah memory leak.
     */
    fun removePermissionListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.removeRequestPermissionResultListener(listener)
        } catch (e: Exception) {
            Log.w(TAG, "Gagal menghapus permission listener: ${e.message}")
        }
    }

    // ════════════════════════════════════════════════════════════════
    // EKSEKUSI PERINTAH SHELL
    // ════════════════════════════════════════════════════════════════

    /**
     * Hasil eksekusi shell command.
     */
    data class CommandResult(
        val success: Boolean,
        val output: String,
        val errorOutput: String,
        val exitCode: Int
    )

    /**
     * Menjalankan perintah shell melalui Shizuku.newProcess().
     * Ini adalah jantung dari aplikasi: eksekusi "wm density" tanpa root.
     *
     * @param command Array string perintah, misal: ["wm", "density", "420"]
     * @return CommandResult berisi status sukses, output, dan exit code.
     */
    fun executeCommand(command: Array<String>): CommandResult {
        if (!hasShizukuPermission()) {
            return CommandResult(
                success = false,
                output = "",
                errorOutput = "Tidak memiliki izin Shizuku",
                exitCode = -1
            )
        }

        var process: Process? = null
        return try {
            Log.d(TAG, "Menjalankan perintah: ${command.joinToString(" ")}")

            // Shizuku.newProcess() → membuat Process dengan hak akses shell
            // Parameter: command array, env variables (null = inherit), working dir (null = default)
            process = Shizuku.newProcess(command, null, null)

            // Baca output standar
            val outputReader = BufferedReader(InputStreamReader(process.inputStream))
            val output = outputReader.readText().trim()

            // Baca output error
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val errorOutput = errorReader.readText().trim()

            // Tunggu proses selesai (dengan timeout 5 detik)
            val exitCode = process.waitFor()

            Log.d(TAG, "Perintah selesai | Exit code: $exitCode | Output: $output")

            CommandResult(
                success = exitCode == 0,
                output = output,
                errorOutput = errorOutput,
                exitCode = exitCode
            )

        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException saat eksekusi: ${e.message}")
            CommandResult(false, "", "Izin ditolak: ${e.message}", -2)

        } catch (e: Exception) {
            Log.e(TAG, "Exception saat eksekusi perintah: ${e.message}")
            CommandResult(false, "", "Error: ${e.message}", -3)

        } finally {
            // Pastikan proses selalu di-destroy untuk mencegah resource leak
            process?.destroy()
        }
    }

    // ════════════════════════════════════════════════════════════════
    // LOGIKA SPESIFIK: SET DPI
    // ════════════════════════════════════════════════════════════════

    /**
     * Sealed class untuk merepresentasikan hasil operasi DPI.
     * Lebih ekspresif dibanding boolean biasa.
     */
    sealed class DpiResult {
        data class Success(val message: String) : DpiResult()
        data class Error(val message: String) : DpiResult()
    }

    /**
     * Mengatur DPI layar sistem.
     *
     * Validasi:
     * - dpi == 0  → reset ke default ("wm density reset")
     * - dpi < 200 atau > 800 → tolak dengan pesan error
     * - dpi valid → jalankan "wm density <dpi>"
     *
     * @param dpi Nilai DPI yang diinginkan (0 = reset)
     * @return DpiResult.Success atau DpiResult.Error
     */
    fun setSystemDpi(dpi: Int): DpiResult {
        // ── Validasi input ──
        when {
            dpi == 0 -> {
                // Reset DPI ke nilai default pabrik
                val result = executeCommand(arrayOf("wm", "density", "reset"))
                return if (result.success) {
                    DpiResult.Success("DPI berhasil direset ke nilai default")
                } else {
                    DpiResult.Error("Gagal mereset DPI: ${result.errorOutput}")
                }
            }

            dpi < 200 -> {
                return DpiResult.Error(
                    "DPI terlalu rendah ($dpi). Nilai minimum adalah 200.\n" +
                    "DPI sangat rendah dapat membuat UI tidak terbaca."
                )
            }

            dpi > 800 -> {
                return DpiResult.Error(
                    "DPI terlalu tinggi ($dpi). Nilai maksimum adalah 800.\n" +
                    "DPI sangat tinggi dapat membuat elemen UI terlalu kecil."
                )
            }

            else -> {
                // Eksekusi perubahan DPI
                val result = executeCommand(arrayOf("wm", "density", dpi.toString()))
                return if (result.success) {
                    DpiResult.Success("DPI berhasil diubah menjadi $dpi")
                } else {
                    DpiResult.Error("Gagal mengubah DPI: ${result.errorOutput.ifEmpty { "Error tidak diketahui" }}")
                }
            }
        }
    }

    /**
     * Mendapatkan nilai DPI saat ini dari sistem.
     * Menjalankan "wm density" tanpa argumen untuk membaca status.
     *
     * @return Nilai DPI saat ini, atau null jika gagal dibaca.
     */
    fun getCurrentDpi(): Int? {
        if (!hasShizukuPermission()) return null

        val result = executeCommand(arrayOf("wm", "density"))
        if (!result.success) return null

        // Output format: "Physical density: 420" atau "Override density: 320"
        return try {
            val line = result.output.lines()
                .firstOrNull { it.contains("density", ignoreCase = true) }
                ?: return null

            // Ambil angka di akhir baris
            line.trim().split(":").lastOrNull()?.trim()?.toIntOrNull()
        } catch (e: Exception) {
            Log.w(TAG, "Gagal parse output DPI: ${result.output}")
            null
        }
    }
}
